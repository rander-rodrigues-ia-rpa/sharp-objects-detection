# Cortantes > 2025-04-09 8:25pm
https://universe.roboflow.com/datasetsai/cortantes-gnax9

Provided by a Roboflow user
License: Public Domain

